package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;

import runners.SQLQueries;

public class customerDAO {
	int updated = 0;

public void  queryGetExistingAccount(int SSN) throws SQLException {
	Connection con = null;
	ResultSet myRs = null;
	try {
		// 1. Get a connection to database. Call from DBConn class
		con = DBConn.getConnection();
		
		System.out.println("Database connection successful!\n");
	// 2. Create a statement
      PreparedStatement myStmt2 = con.prepareStatement(SQLQueries.queryGetExistingAccount);
		
		myStmt2.setInt(1,SSN);
		
		// 3. Execute SQL Query
		myRs = myStmt2.executeQuery();
		
		if (myRs.next() == false) {
			System.out.println("NO RECORDS FOUND: Please review details and try again.");
			
			}
		
		else {
			System.out.println("FIRSTNAME" + "\t" + "MIDDLENAME"  +"\t" + "LASTNAME" +"\t" + "SSN" +"\t\t"  + "STREET NAME"+ "\t" + "APT NO"  
								 + "\t" + "CITY" + "\t\t" + "STATE" + "\t" + "COUNTRY"+ "\t\t" + "ZIP"+"\t" + "PHONE" +"\t" + "EMAIL"+"\t\t\t" + "CREDIT CARD NO"  );	
			
		
			// 4. Process the result set
		
			System.out.print(myRs.getString("FIRST_NAME") + "\t");  
			System.out.print(myRs.getString("MIDDLE_NAME") + "\t\t");
			System.out.print(myRs.getString("LAST_NAME") + "\t\t"); 
			System.out.print(myRs.getInt("SSN") + "\t"); 
			System.out.print(myRs.getString("STREET_NAME") + "\t"); 
			System.out.print(myRs.getString("APT_NO") + "\t"); 
			System.out.print(myRs.getString("CUST_CITY") + "\t\t"); 
			System.out.print(myRs.getString("CUST_STATE") + "\t" + myRs.getString("CUST_COUNTRY") + "\t");
			System.out.print(myRs.getString("CUST_ZIP") + "\t");
			System.out.print(myRs.getInt("CUST_PHONE") + "\t");
			System.out.print(myRs.getString("CUST_EMAIL") + "\t");
			System.out.println(myRs.getString("CREDIT_CARD_NO"));
		}
			//while (myRs.next()) {
		//}
		//}
	}
	catch (SQLException sq) {
		sq.printStackTrace();
	}
	catch (Exception exc) {
		exc.printStackTrace();
	}
	finally {
		if (myRs != null) {
			myRs.close();
		}
		
		
		if (con != null) {
			con.close();
		}
	}
}
			
		
public void  queryModifyExistingAccount(String LAST_NAME, String STREET_NAME, String APT_NO, String CUST_CITY, String CUST_STATE, 
		String CUST_COUNTRY, String CUST_ZIP, int CUST_PHONE, int SSN) throws SQLException {
			Connection con = null;
			ResultSet myRs = null;
			try {
				// 1. Get a connection to database
				con = DBConn.getConnection();

			// 2. Create a statement
		      PreparedStatement myStmt1 = con.prepareStatement(SQLQueries.queryModifyExistingAccount);
				
				
				// 3. Execute SQL Query
				myStmt1.setString(1, LAST_NAME);
				myStmt1.setString(2, STREET_NAME);
				myStmt1.setString(3, APT_NO);
				myStmt1.setString(4, CUST_CITY);
				myStmt1.setString(5, CUST_STATE);
				myStmt1.setString(6, CUST_COUNTRY);
				myStmt1.setString(7, CUST_ZIP);
				myStmt1.setInt(8, CUST_PHONE);
				myStmt1.setInt(9, SSN);

			
				//myStmt1.executeUpdate();
						
					updated = myStmt1.executeUpdate();
					if (updated > 0) {
						System.out.println("RECORD UPDATED!");
						
						String query5 = "select * from cdw_sapp_customer where SSN = " + SSN;
						ResultSet rs = myStmt1.executeQuery(query5);
						System.out.println();
						
					
						while (rs.next()) {
							System.out.println("Name : "  + rs.getString("FIRST_NAME") + " "  + rs.getString("MIDDLE_NAME")  + " "+ rs.getString("LAST_NAME"));
							//System.out.println("Credit Card Number : " + rs.getString("CREDIT_CARD_NO"));
							System.out.println("Address : " + rs.getString("APT_NO") + " "	+ rs.getString("STREET_NAME") );
							System.out.println(rs.getString("CUST_CITY") + " " + rs.getString("CUST_STATE") + "," + " " + rs.getInt("CUST_ZIP"));
							System.out.println(rs.getString("CUST_COUNTRY"));
							System.out.println("Phone : " + rs.getInt("CUST_PHONE")); 
							System.out.println("Last Updated : " + rs.getString("LAST_UPDATED"));
							
						}
					
				}
			}
			catch (Exception exc) {
				exc.printStackTrace();
			}
			finally {
				if (myRs != null) {
					myRs.close();
				}
				
				if (con != null) {
					con.close();
				}
			}

		}

public void getMonthlyBill(String CREDIT_CARD_NO, int MONTH, int YEAR) throws SQLException {
	
	Connection con = null;

	//ResultSet myRs = null;
	try {
		// 1. Get a connection to database
		con = DBConn.getConnection();
		
		System.out.println("Database connection successful!\n");
	// 2. Create a statement

	PreparedStatement myPs = con.prepareStatement(SQLQueries.queryMonthlyBillCreditCard);
	
		
	myPs.setString(1, CREDIT_CARD_NO);
	myPs.setInt(2, MONTH);
	myPs.setInt(3, YEAR);
		
		
	//3. Execute SQL Query

		ResultSet myRs = myPs.executeQuery();

		if (myRs.next()== false) {
			
			System.out.println("NO AVAILABLE RECORDS: Please review details and try again.");
			}
		
	else {
		System.out.println("CREDIT CARD NO" + "\t\t" + "TRANSACTION DATE"  + "\t" + "TOTAL MONTHLY BILL");
	}
		System.out.print(myRs.getString("CREDIT_CARD_NO") + "\t ");
		//System.out.println(myRs2.getInt(MONTH));
	    System.out.print(myRs.getInt("MONTH") + "/" + myRs.getInt("YEAR") + "\t\t\t " ); 
		//System.out.print(myRs2.getString("SSN") + "\t\t\t ");
		//System.out.print(myRs2.getString("TRANSACTION_TYPE") + "\t\t");
		System.out.println(myRs.getString("Total Monthly Bill"));
		
		while(myRs.next()) {
			System.out.print(myRs.getString("CREDIT_CARD_NO") + "\t\t ");
		    System.out.print(myRs.getInt("MONTH") + "/" + myRs.getInt("YEAR") + "\t\t\t " ); 
			//System.out.print(myRs.getString("SSN") + "\t\t\t ");
			System.out.print(myRs.getString("TRANSACTION_TYPE") + "\t\t");
			System.out.println(myRs.getString("Total Monthly Bill"));
		}
		
	
		//}
	}
	catch (Exception exc) {
		exc.printStackTrace();
	}
	finally {
//		if (myRs != null) {
//			myRs.close();
//		}
		
		if (con != null) {
			con.close();
		}
	}
}

public void displayTransactionBtwndates(int CUST_SSN, int DAY,int DAY1, int MONTH, int MONTH1, int YEAR, int YEAR1) throws SQLException {
	// TODO Auto-generated method stub
	Connection con = null;
	Statement myStmt = null;
	ResultSet myRs = null;
	try {
		// 1. Get a connection to database
		con = DBConn.getConnection();
		
		System.out.println("Database connection successful!\n");
	// 2. Create a statement
	PreparedStatement myStmt1 = con.prepareStatement(SQLQueries.queryTransactionsBetweenDates);
		
		myStmt1.setInt(1, CUST_SSN);
		myStmt1.setInt(2, DAY); 
		myStmt1.setInt(3, DAY1);
		myStmt1.setInt(4, MONTH);
		myStmt1.setInt(5, MONTH1);
		myStmt1.setInt(6, YEAR);
		myStmt1.setInt(7, YEAR1);
		
//3. Execute SQL Query
		myRs = myStmt1.executeQuery();
		
		String query5 = "select * from cdw_sapp_customer where SSN = " + CUST_SSN;
		myRs = myStmt1.executeQuery(query5);
		System.out.println();
		
		//CHECK
		myRs = myStmt1.executeQuery();
		
		if (myRs.next() == false) {
			System.out.println("NO AVAILABLE RECORDS: Please review details and try again.");
		}
		else {
			System.out.println("CUSTOMER DETAILS");
			System.out.println();
			System.out.println("Name : "  + myRs.getString("FIRST_NAME") + " "  +myRs.getString("MIDDLE_NAME")  + " "+ myRs.getString("LAST_NAME"));
			System.out.println("Address : " + myRs.getString("APT_NO") + " "	+ myRs.getString("STREET_NAME") );
			System.out.println(myRs.getString("CUST_CITY")  + " " + myRs.getString("CUST_STATE") + "," + " "+ myRs.getInt("CUST_ZIP"));
			System.out.println(myRs.getString("CUST_COUNTRY"));
			System.out.println("Phone: " + myRs.getInt("CUST_PHONE")); 
			System.out.println("Email : " + myRs.getString("CUST_EMAIL"));
			System.out.println("Credit Card Number : " + myRs.getString("CREDIT_CARD_NO")); 
			System.out.println();
			System.out.println("DATE" + "\t\t" + "TRANSACTION VALUE" + "\t" + "TRANSACTION TYPE");
		}
		// 4. Process the result set
		while (myRs.next()) {
			System.out.print(myRs.getInt("DAY")+ "/" + myRs.getInt("MONTH")+ "/" + myRs.getString("YEAR") + "\t");
			System.out.print("$" + myRs.getString("TRANSACTION_VALUE") + "\t\t\t ");
			System.out.println(myRs.getString("TRANSACTION_TYPE"));
		}
	}
	catch (Exception exc) {
		exc.printStackTrace();
	}
	finally {
		if (myRs != null) {
			myRs.close();
		}
		
		if (myStmt != null) {
			myStmt.close();
		}
		
		if (con != null) {
			con.close();
		}
	}
}


}		