package DAO;

import java.sql.*;

public class DBConn {
	
	private static Connection conn = null;

    public static Connection getConnection() throws SQLException {
    	

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cdw_sapp?useSSL=false&serverTimezone=CST","root","mysql");
        
            return conn;
    }

}
