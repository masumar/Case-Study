package runners;

import java.sql.*;
import java.util.*;
import DAO.customerDAO;;

public class CustomerRunner {
	
	
	
	public void getCustomerItems() throws SQLException {
	
		String choice = "";
		int SSN;
		int CUST_SSN;
		int number;
		String LAST_NAME = " ";
		String CREDIT_CARD_NO = " ";
		String STREET_NAME = " ";
		String CUST_CITY = " ";
		String CUST_STATE = " ";
		String CUST_COUNTRY = " ";
		String CUST_ZIP = " ";
		String CUST_EMAIL = " ";
		String LAST_UPDATED = " ";
		int CUST_PHONE = 0;
		int MONTH, MONTH1 = 0;
		int YEAR, YEAR1 = 0;
		int DAY, DAY1 = 0;
		String BRANCH_STATE = " ";
		String STATE = " ";
		String TRANSACTION_TYPE = " ";
		String BRANCH_CODE = " ";
		String TRANSACTION_VALUE = " ";
		String APT_NO;
		
		
		
		// USER MENU / MAIN MENU FOR CUSTOMER DETAILS MODULE
		
				System.out.println("Please select one of the following options  ");
				System.out.println();
				System.out.println("CUSTOMER DETAILS MODULE ");
				System.out.println("***************************************************************************************** ");
				System.out.println("1) To  check  the  existing  account  details  of  a customer ");		
				System.out.println("2) To  modify  the  existing  account  details  of  a customer  ");
				System.out.println("3) To generate  monthly  bill  for a credit  card number for a given month and year ");
				System.out.println("4) To  display the transactions made by a customer between two dates ");
				System.out.println();
				System.out.println("***************************************************************************************** ");
		
		
		// Scan User Input
	System.out.println();
	System.out.println("Please enter your selection: ");
	Scanner caseScanner = new Scanner(System.in);
	choice = caseScanner.nextLine();
	
	switch(choice) {
	case "1" :
		System.out.println();
		System.out.println("Thank you for the information. You've selected to retrieve customer account details");
		System.out.println();
		System.out.println("Please enter the Customer's SSN: ");
		Scanner scan = new Scanner(System.in);
		SSN = scan.nextInt();
		
		customerDAO cdao = new customerDAO();
		cdao.queryGetExistingAccount(SSN);
		
		
		break;
		
		
	case "2" :
		System.out.println();
		System.out.println("Thank you for the information. You've selected to update customer account details");
		System.out.println();
		System.out.println("To begin, please enter customer's SSN you would like to update : ");
				
			Scanner five = new Scanner(System.in);
			SSN = five.nextInt();
			boolean isSSN;
			if(Integer.toString(SSN).length() >= 10 || Integer.toString(SSN).length()<= 8) 
			{ 
				System.out.println("Please enter a valid SSN");
				do {
					SSN= five.nextInt();
					isSSN = (Integer.toString(SSN).length()) == 9;
					if(!isSSN) 
					{
						System.out.println("Please enter a valid SSN");
					}
				}while (!isSSN);
			}
				System.out.println();

				
				System.out.println("Please update customer's Last Name : ");
				Scanner a = new Scanner(System.in);
				LAST_NAME = a.nextLine();
				System.out.println();
				
//				System.out.println("Please update customer's Credit card number: ");
//				Scanner cc = new Scanner(System.in);
//				CREDIT_CARD_NO = cc.nextLine();
//				System.out.println();
				
				System.out.println("Please update customer's Apartment Number : ");
				Scanner b = new Scanner(System.in);
				APT_NO = b.nextLine();
				System.out.println();
				
				System.out.println("Please update customer's Street Name: ");
				Scanner c = new Scanner(System.in);
				STREET_NAME = c.nextLine();
				System.out.println();
										
				System.out.println("Please update customer's City: ");
				Scanner d = new Scanner(System.in);
				CUST_CITY = d.nextLine();
				System.out.println();
				
				System.out.println("Please update customer's State: ");
				Scanner e = new Scanner(System.in);
				CUST_STATE = e.nextLine();
				System.out.println();
									
				System.out.println("Please update customer's Country : ");
				Scanner f = new Scanner(System.in);
				CUST_COUNTRY = f.nextLine();
				System.out.println();
				
				System.out.println("Please update customer's Zip Code: ");
				Scanner g = new Scanner(System.in);
				CUST_ZIP = g.nextLine();
				System.out.println();	
				boolean isCUST_ZIP;
				if(CUST_ZIP.length() > 5 || CUST_ZIP.length() < 5) 
				{ 
					System.out.println("Please enter a valid 5-digit zipcode");
					do {
						CUST_ZIP= g.nextLine();
						isCUST_ZIP = (CUST_ZIP.length() == 5);
						if(!isCUST_ZIP) 
						{
							System.out.println("Please enter a valid 5-digit zipcode");
						}
					}while (!isCUST_ZIP);
				}
				
				System.out.println("Please update customer's Phone Number: ");
				Scanner h = new Scanner(System.in);
				CUST_PHONE =Integer.parseInt(h.nextLine());
				System.out.println();
				
//				System.out.println("Please update customer's SSN");
//				SSN = five.nextInt();
//				System.out.println();
//				boolean isSSN1;
//				if(Integer.toString(SSN).length() >= 10 || Integer.toString(SSN).length()<= 8) 
//				{ 
//					System.out.println("Please enter a valid SSN");
//					do {
//						SSN= five.nextInt();
//						isSSN1 = (Integer.toString(SSN).length()) == 9;
//						if(!isSSN1) 
//						{
//							System.out.println("Please enter a valid SSN");
//						}
//					}while (!isSSN1);
//				}
				
				customerDAO updatedInfo = new customerDAO();
				updatedInfo.queryModifyExistingAccount(LAST_NAME, STREET_NAME, APT_NO, CUST_CITY, CUST_STATE, CUST_COUNTRY, CUST_ZIP, CUST_PHONE, SSN);	
				break; 
		
	case "3" :
		System.out.println();
		System.out.println("Thank you for the information. You've selected to look up customer monthly bill");
		System.out.println();
		
		System.out.println("Please Enter Customer's credit card number: ");
		Scanner one = new Scanner(System.in);
		CREDIT_CARD_NO = one.nextLine();
		
		System.out.println("Please Enter the month: ");
		Scanner two = new Scanner(System.in);
		MONTH = two.nextInt();
		
		System.out.println("Please Enter the year: ");
		Scanner three = new Scanner(System.in);
		YEAR = three.nextInt();
		
		customerDAO monthlyBill = new customerDAO();
		monthlyBill.getMonthlyBill(CREDIT_CARD_NO, MONTH, YEAR);
		break;
		
	case "4" :
		//System.out.println("Work In Progress........ Come back later!");
		System.out.println();
		System.out.println("Thank you for the information. You've selected to obtain a customer's transactions between two dates");
		System.out.println();
		
		System.out.println("Please Enter Customer's SSN: ");
		Scanner nine = new Scanner(System.in);
		CUST_SSN = nine.nextInt();
		boolean isCUST_SSN;
		if(Integer.toString(CUST_SSN).length()>= 10 || Integer.toString(CUST_SSN).length()<= 8) 
		{ 
			System.out.println("Please enter a valid customer SSN");
			do {
				CUST_SSN= nine.nextInt();
				isCUST_SSN = (Integer.toString(CUST_SSN).length()) == 9;
				if(!isCUST_SSN) 
				{
					System.out.println("Please enter a valid customer SSN");
				}
			}while (!isCUST_SSN);
		}
		
		System.out.println("Please Enter Beginning day: ");
		
		 DAY = nine.nextInt();
			boolean isDAY;
			if(DAY >= 32 || DAY <= 0) 
			{ 
				System.out.println("Please enter a valid day");
				do {
					DAY = nine.nextInt();
					isDAY = (DAY >=1 && DAY <= 31);
					if(!isDAY) 
					{
						System.out.println("Please enter a valid day");
					}
				}while (!isDAY);
			}
			System.out.println("Please Enter Beginning month: ");

			MONTH = nine.nextInt();
			boolean isMONTH;
			if(MONTH <= 0 || MONTH >= 13) 
			{ 
				System.out.println("Please enter a valid month");
				do {
					MONTH = nine.nextInt();
					isMONTH = (MONTH >= 1 && MONTH <= 12);
					if(!isMONTH) 
					{
						System.out.println("Please enter a valid month");
					}
				}while (!isMONTH);
			}
			
			System.out.println("Please Enter Beginning year(YYYY): ");
			
			YEAR = nine.nextInt();
			boolean isYEAR;
			if(Integer.toString(YEAR).length() <= 3 || Integer.toString(YEAR).length() >= 5) 
			{ 
				System.out.println("Please enter a valid year in the following format YYYY");
				do {
					YEAR = nine.nextInt();
					isYEAR = (Integer.toString(YEAR).length() == 4);
					if(!isYEAR) 
					{
						System.out.println("Please enter a valid year in the following format YYYY");
					}
				}while (!isYEAR);
			}
			
		System.out.println("Please Enter Ending day: ");
		
		DAY1 = nine.nextInt();
		boolean isDAY1;
			if(DAY1 >= 32 || DAY1 <= 0) 
			{ 
				System.out.println("Please enter a valid day");
				do {
					DAY1 = nine.nextInt();
					isDAY1 = (DAY1 >=1 && DAY <= 31);
					if(!isDAY1) 
					{
						System.out.println("Please enter a valid day");
					}
				}while (!isDAY1);
			}
		
		System.out.println("Please Enter Ending month: ");
		
		MONTH1 = nine.nextInt();
		boolean isMONTH1;
		if(MONTH1 <= 0 || MONTH1 >= 13) 
		{ 
			System.out.println("Please enter a valid month");
			do {
				MONTH1 = nine.nextInt();
				isMONTH1 = (MONTH1 >= 1 && MONTH1 <= 12);
				if(!isMONTH1) 
				{
					System.out.println("Please enter a valid month");
				}
			}while (!isMONTH1);
		}
	
		
		System.out.println("Please Enter Ending year(YYYY): ");
		Scanner ten = new Scanner(System.in);
		YEAR1 = ten.nextInt();
		boolean isYEAR1;
		if(Integer.toString(YEAR1).length() <= 3 || Integer.toString(YEAR1).length() >= 5) 
		{ 
			System.out.println("Please enter a valid year in the following format YYYY");
			do {
				YEAR1 = nine.nextInt();
				isYEAR1 = (Integer.toString(YEAR1).length() == 4);
				if(!isYEAR1) 
				{
					System.out.println("Please enter a valid year in the following format YYYY");
				}
			}while (!isYEAR1);
		}
		
		customerDAO displayTransaction = new customerDAO();
		displayTransaction.displayTransactionBtwndates(CUST_SSN, DAY, DAY1, MONTH, MONTH1, YEAR, YEAR1);
		
		break;
		
		
	default: 
		System.out.println("Thanks for using the System, Goodbye!");
		System.exit(0);
}
	caseScanner.close();
	}
}
