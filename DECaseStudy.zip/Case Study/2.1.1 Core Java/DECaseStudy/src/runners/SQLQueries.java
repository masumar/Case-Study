package runners;

public class SQLQueries {
	//Transaction details module
    //Query 1 - To display the transactions made by customers living in a given zipcode for a given month and year. Order by day in descending order.
	
    public final static String displayTransByZipMonthYear = "SELECT * FROM CDW_SAPP_CREDITCARD JOIN CDW_SAPP_CUSTOMER ON CDW_SAPP_CUSTOMER.SSN = CDW_SAPP_CREDITCARD.CUST_SSN "
    		+ "WHERE CDW_SAPP_CUSTOMER.CUST_ZIP = ? AND CDW_SAPP_CREDITCARD.MONTH = ? AND CDW_SAPP_CREDITCARD.YEAR = ? ORDER BY CDW_SAPP_CREDITCARD.DAY DESC;";
   
    //Query 2 - To display the number and total values of transactions for a given type.
    
    public final static String displayTValuesByTransType = "SELECT COUNT(TRANSACTION_ID) AS 'Number of Trans', SUM(TRANSACTION_VALUE) AS 'Total Value', TRANSACTION_TYPE FROM CDW_SAPP_CREDITCARD WHERE TRANSACTION_TYPE = ? GROUP BY TRANSACTION_TYPE;";    
    
    //Query 3 - To display the number and total values of transactions for branches in a given state
    public final static String displayValuesByState = "SELECT cdw_sapp_branch.BRANCH_STATE, cdw_sapp_creditcard.BRANCH_CODE, SUM(cdw_sapp_creditcard.TRANSACTION_VALUE) AS 'TOTAL VALUE OF TRANSACTIONS', "
  		  + "COUNT(cdw_sapp_creditcard.BRANCH_CODE) AS 'NUMBER OF TRANSACTIONS' \r\n" + 
  			"FROM cdw_sapp_creditcard \r\n" + 
  			"LEFT JOIN cdw_sapp_branch\r\n" + 
  			"ON cdw_sapp_branch.BRANCH_CODE = cdw_sapp_creditcard.BRANCH_CODE\r\n" + 
  			"where BRANCH_STATE = ? GROUP BY BRANCH_CODE;";   
    
    
    //Customer details module
    
    //Query 4 - To check the existing account details of a customer.
    public final static String queryGetExistingAccount = "SELECT * FROM CDW_SAPP_CUSTOMER WHERE SSN=?;";
    
    //Query 5 - To modify the existing account details of a customer.
    public final static String queryModifyExistingAccount = "UPDATE CDW_SAPP_CUSTOMER SET LAST_NAME=?, STREET_NAME=?, APT_NO=?, CUST_CITY=?, CUST_STATE=?, CUST_COUNTRY=?, CUST_ZIP=?, CUST_PHONE=? WHERE SSN=?;";
    
    //Query 6 - To generate monthly bill for a credit card number for a given month and year.
    
    public final static String queryMonthlyBillCreditCard = "SELECT CREDIT_CARD_NO, SUM(TRANSACTION_VALUE) AS 'Total Monthly Bill', MONTH, YEAR FROM CDW_SAPP_CREDITCARD WHERE CREDIT_CARD_NO = ? AND MONTH=? AND year=?;";
    
    //Query 7 - To display the transactions made by a customer between two dates. Order by year, month, and day in descending order.
    public final static String queryTransactionsBetweenDates = "SELECT TRANSACTION_ID, DAY, MONTH, YEAR, CREDIT_CARD_NO, CUST_SSN, BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE FROM CDW_SAPP_CREDITCARD WHERE CUST_SSN = ? AND DATE(CONCAT(YEAR, '-', MONTH, '-', DAY)) BETWEEN '?-?-?' AND '?-?-?' ORDER BY DATE(CONCAT(YEAR, '-', MONTH, '-', DAY)) DESC;";

}
