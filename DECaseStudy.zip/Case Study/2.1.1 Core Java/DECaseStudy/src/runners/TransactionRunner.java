package runners;

import java.sql.*;
import java.util.*;
import DAO.transactionDAO;
//import DAO.DBConn;

public class TransactionRunner {
	//static Connection myConn = null;

	//static transactionDAO transDAO;
	
	public void getTransactionItems() throws SQLException {
		
	//public static void main(String[] args) throws Exception  {
		int userInput = 0;
		String CUST_ZIP = "";
		int MONTH, YEAR = 0;
		String transt = "";
		//String TRANSACTION_VALUE = "";
		String BRANCH_STATE ="";
		//String BRANCH_CODE ="";
		
		
		// USER MENU
		
		System.out.println("Please select one of the following options  ");
		System.out.println();
		System.out.println("TRANSACTION DETAILS MODULE ");
		System.out.println("******************************************************************************************** ");
		System.out.println("1) Display transactions made by customers in a given zipcode for a given Month & Year " );		
		System.out.println("2) Display number and total values of transactions for a given type");
		System.out.println("3) Display number and total values of transactions for branches by state ");
		System.out.println();
		System.out.println("******************************************************************************************** ");
		
		Scanner myscan = new Scanner(System.in);
		System.out.print("Make A Selection (-1 to exit the system): ");
		userInput = myscan.nextInt();
		
		switch(userInput) {
		
		case 1 :
		System.out.println();
		System.out.println("You've selected to display transactions of customers living in a given zipcode ");
		System.out.println();
		System.out.println("Please enter the zipcode you would like to look up: ");
		
		Scanner scanner = new Scanner(System.in);
		CUST_ZIP = scanner.nextLine();
		boolean isCUST_ZIP1;
		if(CUST_ZIP.length() > 5 || CUST_ZIP.length() < 5) 
		{ 
			System.out.println("Please enter a valid 5-digit zipcode");
			do {
				CUST_ZIP= scanner.nextLine();
				isCUST_ZIP1 = (CUST_ZIP.length() == 5);
				if(!isCUST_ZIP1) 
				{
					System.out.println("Please enter a valid 5-digit zipcode");
				}
			}while (!isCUST_ZIP1);
		}
		
		System.out.println();
		System.out.println("Please Enter Month: ");
		Scanner mth = new Scanner(System.in);
		MONTH = mth.nextInt();
		System.out.println();

		System.out.println("Please Enter Year: ");
		Scanner yr = new Scanner(System.in);
		YEAR = yr.nextInt();
		System.out.println();
		
		transactionDAO transbyzip = new transactionDAO();
		transbyzip.displayTransByZipMonthYer(CUST_ZIP, MONTH, YEAR);
		//transbyzip.displayTransByZipMonthYear(CUST_ZIP);
		break;
		
		case 2 :
			System.out.println();
			System.out.println("You selected to display total values based on transaction type ");
			System.out.println();
			System.out.println("Please enter the transaction type you would like to look up: ");
			Scanner scann = new Scanner(System.in);
			transt = scann.nextLine();
			
			transactionDAO transtype = new transactionDAO();
			transtype.displayValuesByType(transt);
			
			break;
			
		case 3 :
			System.out.println();
			System.out.println("You selected to get the number and total value of transaction for a branch in a given state");
			System.out.println();
			
			System.out.println("Please Enter the branch state: ");
			Scanner eleven = new Scanner(System.in);
			BRANCH_STATE = eleven.nextLine();
			boolean isBRANCH_STATE;
			if(BRANCH_STATE.length() > 2 || BRANCH_STATE.length() < 2) 
			{ 
				System.out.println("Please enter a valid 2-letter state code");
				do {
					BRANCH_STATE = eleven.nextLine();
					isBRANCH_STATE = (BRANCH_STATE.length() == 2);
					if(!isBRANCH_STATE) 
					{
						System.out.println("Please enter a valid 2-letter state code");
					}
				}while (!isBRANCH_STATE);
			}
			//eleven.hasNext();
			
			
			transactionDAO transbranch = new transactionDAO();
			transbranch.displayValuesByState(BRANCH_STATE);
			break;
			
		default: 
			System.out.println("Thanks for using the System, Goodbye!");
			System.exit(0);
	}
		myscan.close();
	}
}
