package runners;

//import java.sql.*;
import java.util.*;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import runners.TransactionRunner;
//import DAO.transactionDAO;

public class MainRunner {
	
	final static JDialog dialog = new JDialog();
	
	
	public static void main(String[] args) throws Exception {
		
		//transactionDAO tr = new transactionDAO();
		int myInput;
		
		
			// USER MENU TO WELCOME USER AND SELECT AN OPTION
		
				System.out.println("***WELCOME TO THE CREDIT CARD MANAGEMENT SYSTEM!!***");
				System.out.println();
				System.out.println();
				System.out.println("Please choose from the options below to enter the Transaction or Customer Details Module");
				//System.out.println("Please make a selection : ");
				System.out.println();
				System.out.println("**********************MAIN MENU******************************** ");
				System.out.println("1) RETRIEVE TRANSACTION DETAILS " );		
				System.out.println("2) RETRIEVE CUSTOMER DETAILS ");
				System.out.println();
				System.out.println("*************************************************************** ");
		
				Scanner myscan = new Scanner(System.in);
				System.out.print("Make A Selection (-1 to exit the system): ");
				myInput = myscan.nextInt();
				//do {
					
				// use a switch
					try {

				if (myInput == 1) {
					System.out.println( );
					System.out.println( "Entering Transactions Module ...");
					TransactionRunner trun = new TransactionRunner();
					trun.getTransactionItems();
					//break;
				}
				else if (myInput == 2){
					//System.out.println( "Work in progress..... Please try again later!");
					System.out.println( );
					System.out.println( "Entering Customers Module ...");
					CustomerRunner crun = new CustomerRunner();
					crun.getCustomerItems();
					//break;
					
				}
				else if (myInput == -1) {
					dialog.setAlwaysOnTop(true);
					JOptionPane.showMessageDialog(dialog, "Uh oh, See you Later! GOODBYE!");
					//System.out.println();
					//System.out.println("Thanks for using the credit card system. Goodbye!");
					//System.exit(0);
				}
				
				else {
					//while(myInput >2) 
					Scanner myscn = new Scanner(System.in);
					//System.out.print("Make A Selection (-1 to exit the system): ");
					
					System.out.println( "Would you like to try again? (Please enter a valid option!)");
					System.out.println();
					System.out.println( " \tEnter 1 or 2 (-1 to exit the system): ");
					int myInput2 = myscn.nextInt();
					if (myInput2 == 1) {
						System.out.println( );
						System.out.println( "Entering Transactions Module ...");
						TransactionRunner trun = new TransactionRunner();
						trun.getTransactionItems();
						//break;
					}
					else if (myInput2 == 2){
						//System.out.println( "Work in progress..... Please try again later!");
						System.out.println( );
						System.out.println( "Entering Customers Module ...");
						CustomerRunner crun = new CustomerRunner();
						crun.getCustomerItems();
						//break;
						
					}
					else if (myInput2 == -1) {
						//JOptionPane.showMessageDialog(null, "Uh oh, See you Later! GOODBYE!");
						System.out.println();
						System.out.println("Thanks for using the credit card system. Goodbye!");
						System.exit(0);
					}
					else {
						//System.exit(0);
						
						System.out.println( "Would you like to try again? (Please enter a valid option!)");
						System.out.println();
						System.out.println( " \tEnter 1 or 2 (-1 to exit the system): ");
						myInput2 = myscn.nextInt();
					}
					myscn.close();
					//break;
					
					myInput = myscan.nextInt();
					//System.exit(0);
				}
					}catch(InputMismatchException ime) {
						System.out.println("Input Mismatch Exception. Please enter an integer: ");
						myscan.next();
						
					}
				//}
				//while(myInput != -1);
				System.out.println();
				System.out.println();
				System.out.println("Thanks for using the credit card system. Goodbye!");
				myscan.close();

	}
}
