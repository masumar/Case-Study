package classModels;

import java.util.*;

public class Branch {
	
	//using the given Source File Structure to declare variables
	private int BRANCH_CODE;
	private String BRANCH_NAME;
	private String BRANCH_STREET;
	private String BRANCH_CITY;
	private String BRANCH_STATE;
	private int BRANCH_ZIP;
	private String BRANCH_PHONE;
	private Date LAST_UPDATED;
	
	//empty constructor
    public Branch()
    {
        
    }
    //constructor with parameters for Branch
	public Branch(int bRANCH_CODE, String bRANCH_NAME, String bRANCH_STREET, String bRANCH_CITY, String bRANCH_STATE,
			int bRANCH_ZIP, String bRANCH_PHONE, Date lAST_UPDATED) {
		
		BRANCH_CODE = bRANCH_CODE;
		BRANCH_NAME = bRANCH_NAME;
		BRANCH_STREET = bRANCH_STREET;
		BRANCH_CITY = bRANCH_CITY;
		BRANCH_STATE = bRANCH_STATE;
		BRANCH_ZIP = bRANCH_ZIP;
		BRANCH_PHONE = bRANCH_PHONE;
		LAST_UPDATED = lAST_UPDATED;
	}

	//get and set for Branch Code
	public int getBRANCH_CODE() {
		return BRANCH_CODE;
	}

	public void setBRANCH_CODE(int bRANCH_CODE) {
		BRANCH_CODE = bRANCH_CODE;
	}

	//get and set for Branch Name
	public String getBRANCH_NAME() {
		return BRANCH_NAME;
	}

	public void setBRANCH_NAME(String bRANCH_NAME) {
		BRANCH_NAME = bRANCH_NAME;
	}

	//get and set for Branch Street
	public String getBRANCH_STREET() {
		return BRANCH_STREET;
	}

	public void setBRANCH_STREET(String bRANCH_STREET) {
		BRANCH_STREET = bRANCH_STREET;
	}

	//get and set for Branch City
	public String getBRANCH_CITY() {
		return BRANCH_CITY;
	}

	public void setBRANCH_CITY(String bRANCH_CITY) {
		BRANCH_CITY = bRANCH_CITY;
	}

	//get and set for Branch State
	public String getBRANCH_STATE() {
		return BRANCH_STATE;
	}

	public void setBRANCH_STATE(String bRANCH_STATE) {
		BRANCH_STATE = bRANCH_STATE;
	}

	//get and set for Branch Zip
	public int getBRANCH_ZIP() {
		return BRANCH_ZIP;
	}

	public void setBRANCH_ZIP(int bRANCH_ZIP) {
		BRANCH_ZIP = bRANCH_ZIP;
	}

	//get and set for Branch Phone
	public String getBRANCH_PHONE() {
		return BRANCH_PHONE;
	}

	public void setBRANCH_PHONE(String bRANCH_PHONE) {
		BRANCH_PHONE = bRANCH_PHONE;
	}

	//get and set for LAST_UPDATED --> SQL Date stamp
	public Date getLAST_UPDATED() {
		return LAST_UPDATED;
	}

	public void setLAST_UPDATED(Date lAST_UPDATED) {
		LAST_UPDATED = lAST_UPDATED;
	}
	
	
}
